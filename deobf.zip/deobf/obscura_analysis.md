# Obscura v4.2.2 — deobfuscation / tamper analysis

## Result

The outer packer is fully opened and the main embedded Lua stage was recovered. The supplied file is **not sufficient to reconstruct the exact original program source**, because the real VM intentionally accepts external runtime material before it can pass its own integrity check:

- `_uive98507fd`: a hex-string key that changes the VM key schedule / opcode decoding / string decoding.
- `_q11f9ec32`: an optional packet stream that replaces `mox` bytecode for prototypes carrying a `jmno` id.

This is not a guess based on a failed sandbox run. The real VM computes a recursive integrity value from decoded opcodes, constant-pool bytes and child prototypes. With the file alone (no external key/patch) the value is **1766213219**. The embedded expected value resolves to **1981098924**. The code adds the difference into its key state and then throws a detection error because the two values differ. Therefore a "decompiled original" produced from the file-only opcode stream would be deliberately wrong.

## Layer map

1. **Outer loader (1,282,895 bytes)**
   - staged `RZ[...]` bootstrap
   - custom 85-character Base85 alphabet
   - Base85 decoder
   - DEFLATE-style decompressor
   - outer anti-hook / anti-dump checks
   - hardened `loadstring` / `load` resolution

2. **Decoded embedded stage (1,012,902 bytes)**
   - first VM/bootstrap expression: ~172 KB
   - second/real VM: ~840 KB

3. **Real VM metadata recovered statically**
   - root bytecode: 47,682 bytes = **2,649 instructions** (18 bytes/instruction)
   - root constant pool: **5,461 bytes**
   - root direct children: **34**
   - recursive prototypes present: **102**
   - statically present instructions across prototypes: **10,120**
   - prototypes with empty `mox` and a `jmno` patch id: **19**

## Transport recovered

The outer custom alphabet is:

`r@Y*U_vFgsanHB.pIce^j&8%]#Zf>A;:GLRTd<hNS1l9ObW$m7kD,3EtK(?0uVC`Qq+6['X54=w-PMoi/J)2!`

Its decoder consumes up to 5 Base85 symbols, pads short groups with value 84, and emits 4 bytes (or `count - 1` for the last short group). The huge encoded payload is 1,266,128 characters and decodes to 1,012,902 bytes of Lua source.

## First/bootstrap VM

The first VM executes before the real VM. Its own string-name decoder is an XOR-by-141 layer. Dynamic instrumentation with a **local mock request function** (no network request was sent by this analysis) shows it asks for environment/runtime data such as:

- `gethwid`
- `game`
- `identifyexecutor`
- `getexecutorname`
- `request` / `http_request`
- `type`
- `tostring`
- `string`
- `pcall`

Under the mock environment it attempted two GET requests to the Obscura `/k/<build-token>` endpoint, one nonce/loader-key style request and one request containing runtime metadata (hwid, uid, place, job, executor, etc.). The mock returned 404, so no external runtime material was received.

This explains why the second VM has explicit readers for `_uive98507fd` and `_q11f9ec32`: the protected build is designed to consume runtime state not present as plaintext in the uploaded file.

## `_q11f9ec32` patch format

The second VM parses `_q11f9ec32` as repeated packets:

- 3 bytes: big-endian prototype id
- 3 bytes: big-endian payload length
- N bytes: replacement `mox`

It recursively walks the prototype tree and, where a prototype has `jmno = id`, replaces that prototype's `mox` with the supplied packet payload.

## VM instruction crypto

The real VM stores 18 bytes per instruction. The first 9 bytes carry three encrypted 24-bit fields. Per instruction it:

1. removes instruction-position masks,
2. removes a prototype-id (`eny`) mask,
3. applies a keyed modular decoder (`lch`),
4. uses `op % 111` through a shuffled `lac` table to select a handler,
5. mixes the decoded opcode into a rolling byte state used by operand / constant decoding.

`_uive98507fd`, when present, generates a 455-entry key schedule and a 256-entry permutation that are mixed into this decoder. Without the correct value, the root begins with nonsensical stack operations and fails its recursive integrity hash.

## Anti-tamper: outer layer

Decoded API names:

- `loadstring`
- `load`
- `isfunctionhooked`
- `getfunctionhook`
- `clonefunction`
- `getexecutorname`
- `ishooked`
- `typeof`
- `game`

Checks recovered:

1. `string.dump` must not successfully dump the loader functions.
2. `isfunctionhooked(loadstring/load)` must not report a hook.
3. `isfunctionhooked`, `getfunctionhook`, and `clonefunction` are cross-checked via `string.dump` behavior.
4. `getfunctionhook(loader)` returning a distinct function is treated as a hook.
5. Extra dumpability check on `isfunctionhooked`.
6. `getexecutorname()` is lowercased; two decoded substrings are `delta` and `arceus`. If neither matches and `ishooked` exists, detection is raised.
7. `typeof(game)` is expected to be `Instance`.
8. On success, the loader attempts to recover the original hooked function with `getfunctionhook`, then clone it with `clonefunction`.

Outer failure text:

`-- Detected and blocked by Obscura v4.2.2 | https://obscuravm.com | discord.gg/ obscuravm`

## Anti-tamper: real VM

The second VM has both **visible throws** and **key poisoning**. Important checks recovered:

- intentional `pcall(error(...))` semantics test; if `error` unexpectedly returns, constant decryption is poisoned
- `game` Lua type / `typeof(game)` identity checks
- `debug.gethook` active-hook check
- `math.noise` binary floating-point fingerprint
- `Vector3` float precision fingerprint around `2^24`
- deterministic `Random.new(7)` fingerprint
- `string.dump` hash snapshots of core VM helper functions
- periodic `string.dump` hash re-checks of dispatch handlers
- operator/helper dump-derived fingerprints
- null-byte string length behavior
- `math.floor(-0.5)` behavior
- `0.1 + 0.2 == 0.3` behavior
- rounding at `2^52` / `2^53`
- recursive opcode/constant/prototype integrity hash
- Roblox physics fingerprint using `RunService`, `PhysicsService`, collision groups, two Parts, 8 Heartbeats and a rounded Y coordinate
- environment probing through `tostring({})`
- rejection of `game` when it is a plain Lua table
- `request` / `http_request` / `loadstring` hook checks using `isfunctionhooked` and `string.dump`
- hashed blocklist scan of string keys in the environment and `_G`

Visible second-stage failure text:

`Detected and blocked by Obscura | https://obscuravm.com | discord.gg/ obscuravm`

The exact recovered minified code with its `lbx(...)` strings decoded is in `obscura_tamper_region_decoded.lua`.

## Remote-looking `_RX` block client

The real VM contains an HTTP-looking `_RX` block client, but in this specific sample its local `MAP` is initialized empty and no assignment populates it. Therefore I classify that path as **dead/inert in this build**, not evidence by itself that the original source is remotely executed.

The first/bootstrap VM's observed loader-key requests are separate and are real execution-path behavior when a request function is available.

## What is recovered vs. not recovered

Recovered:

- outer loader structure
- custom Base85 transport
- main embedded stage source
- bootstrap VM source
- real VM source
- real VM handler table
- prototype tree and static bytecode blobs
- external-patch format
- outer anti-tamper names and logic
- second-stage anti-tamper strings and logic
- root/static instruction crypto formulas
- proof of the missing-runtime-state integrity mismatch

Not honestly recoverable from this file alone:

- byte-for-byte original user Luau source
- correct real opcode stream if the build expects `_uive98507fd`
- the 19 `jmno` prototype bodies if `_q11f9ec32` is required for this build

A tool claiming to output the "full original" from only this artifact would have to invent those missing values or ignore the VM's own integrity condition.
